/*----------------------------------------------------------------------------
 *      RL-ARM - RTX
 *----------------------------------------------------------------------------
 *      Name:    MAILBOX.C
 *      Purpose: RTX example program
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2011 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/
#include <LPC17xx.h>
#include "uart_polling.h"
#include <RTL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// #define DEBUGGING 1

OS_MUT g_mut_uart;										/* UART printing mutex for proper output */
OS_MUT procon;												/* Mutex for sharing mem between pro and con*/
// OS_MUT num_access;										/* Protect the access of the circular buffer */

OS_SEM emptyBuffer;
OS_SEM fullBuffer;

OS_TID g_tid = 255;

U32 N = 398;											/* Total number of integers */
U32 B = 8;											/* Max size of the message Q*/
U32 P = 4;											/* Create P Producers */
U32 C = 8;											/* Create C Consumers */

U32 cur_producer = 0;
U32 cur_consumer = 0;

U32 task_creator_ctr_pro = 0;
U32 task_creator_ctr_con = 0;

/*
U32 sendTaskCtr = 0;
U32 recvTaskCtr = 0;
*/

U32 msg_counter_rec = 0;


int *buffer;
int tail = 0;
int head = 0;

//int N_arr[] = { 20, 40, 80, 160, 320 };
//int B_arr[] = { 1, 2, 4, 8, 10 };

/*

typedef struct {                      // Message object structure            
  U32 number;                      		// Random number 
} T_NUM;

T_NUM *random_num_global;


os_mbx_declare (MsgBox,320);           // Declare an RTX mailbox              
_declare_box (mpool,sizeof(T_NUM),320);// Dynamic memory pool                
*/



__task void producer_task (void);
__task void consumer_task (void);
//__task void updater_task (void);
__task void init(void);

U32 time_a, time_b;



/*----------------------------------------------------------------------------
 *  Task Producer:  RTX Kernel starts this task with os_sys_init (producer_task)
 *---------------------------------------------------------------------------*/
__task void producer_task (void) {
  
	OS_TID producer_tskid;                          /* assigned identification for producer  */
	U32 msg_counter_send = 0;
	
	
	//Get current task ID
	producer_tskid = os_tsk_self ();
	
  /*
	//os_mut_wait(procon, 0xFFFF);
	if(cur_producer == 0)
	{
// 		os_mbx_init (MsgBox, sizeof(MsgBox));// initialize the mailbox             
 
			os_mut_wait(g_mut_uart, 0xFFFF);
			printf("[producer_task [pid:(%d)] ]: Mailbox Created\n", producer_tskid);
			os_mut_release(g_mut_uart);
		
		cur_producer = 1;
	}
	//os_mut_release(procon);
		*/
		
	//Get Time B
	//time_b = os_time_get() ;

	// Check if the number is the required one
	// .. And also make sure that we still have to send numbers.
	while ( msg_counter_send < N )
	{
		// number generation logic...
		if ( (msg_counter_send % P) == producer_tskid - 2 ) // init is 1, rest follows..
		{
			// random_num_global = _alloc_box(mpool);			/* Allocate a memory for the message   */
		
			/*
			if( random_num_global == NULL )
			{
				os_mut_wait(g_mut_uart, 0xFFFF);
				printf("_alloc_box failed because of no mem available!\n");
				os_mut_release(g_mut_uart);
				exit(1);
			}
			*/
			
			os_sem_wait(&emptyBuffer, 0xFFFF);
			
				buffer[tail] = (U32) msg_counter_send;
				tail = (tail+1) % B;
			
			os_sem_send(&fullBuffer);
			
			// os_mbx_send (MsgBox, random_num_tx, 0xffff); /* Send the message to the mailbox     */
			
			os_mut_wait(g_mut_uart, 0xFFFF);
				
				#ifdef DEBUGGING
				printf("[producer_task [pid:(%d)] ]: Sent %u\n", producer_tskid - 2, msg_counter_send);
				#endif
				
			msg_counter_send++;
			os_mut_release(g_mut_uart);
		}
		else
		{
			msg_counter_send++;		// this process cannot handle this number so increment.
		}
		
	}
	
	//msg_counter_send = 0;
	
	#ifdef DEBUGGING
		os_mut_wait(g_mut_uart, 0xFFFF);
		printf("[producer_task [pid: (%d)] ]: Deleting itself..\n", producer_tskid - 2);
		os_mut_release(g_mut_uart);
	#endif
	
	os_tsk_delete_self ();              /* We are done here, delete this task  */
}

/*----------------------------------------------------------------------------
 *  Task 2: RTX Kernel starts this task with os_tsk_create (consumer_task, 0)
 *---------------------------------------------------------------------------*/
__task void consumer_task (void) {
	
	OS_TID consumer_tskid;                          /* assigned identification for consumer */
		
	U32 recievedInt = 0;
	
	consumer_tskid = os_tsk_self();									/* get it's own task ID */

	

	while( msg_counter_rec < N )
	{
		// os_mbx_wait (MsgBox, (void **)&random_num_global, 0xffff); /* wait for the message    */
		
		// Only print perfect squares..
		os_sem_wait(&fullBuffer, 0xFFFF);
		os_mut_wait(g_mut_uart, 0xFFFF);
		recievedInt = buffer[head];
		head = (head + 1) % B;
		
		#ifdef DEBUGGING
				printf("[consumer_task [pid:(%d)] ]: Received %u\n", consumer_tskid - 2 - P, recievedInt);
		#endif	
		
		if( (sqrt((float)recievedInt) - (int)sqrt(recievedInt) )  == 0.0 )	// Perfect sqrt	
				printf("[consumer_task [pid:(%d)] ]: %d | %0.0f\n", consumer_tskid - 2 - P, recievedInt, sqrt(recievedInt) );
					
		msg_counter_rec += 1;
		os_mut_release(g_mut_uart);
		os_sem_send(&emptyBuffer);
		
	}


	//Get Time B 
	time_b = os_time_get();
	
	os_mut_wait(g_mut_uart, 0xFFFF);
	printf("Time to transmit data: %0.6f\n", (float)(((float)time_b - time_a)/1000000) );
	os_mut_release(g_mut_uart);

	// os_dly_wait(10);
	#ifdef DEBUGGING
		os_mut_wait(g_mut_uart, 0xFFFF);
		printf("[consumer_task [pid: (%d)] ]: Deleting itself..\n", consumer_tskid - 2 - P);
		os_mut_release(g_mut_uart);
	#endif
	
	os_tsk_delete_self ();              /* We are done here, delete this task  */
}


		
__task void init(void)
{
	os_mut_init(&g_mut_uart);
	
	
	os_sem_init(&emptyBuffer, B);
	os_sem_init(&fullBuffer, 0);
	
	//Get Time A
	time_a = os_time_get();
	
	for( task_creator_ctr_pro = 0; task_creator_ctr_pro < P; task_creator_ctr_pro++ )
	{
		os_tsk_create(producer_task, 0);
		#ifdef DEBUGGING
			os_mut_wait(g_mut_uart, 0xFFFF);
			printf("[init]: Created producer [%d]\n", task_creator_ctr_pro);
			os_mut_release(g_mut_uart);
		#endif
	}
	
	
	for( task_creator_ctr_con = 0; task_creator_ctr_con < C; task_creator_ctr_con++ )
	{
		os_tsk_create(consumer_task, 0);
		#ifdef DEBUGGING
			os_mut_wait(g_mut_uart, 0xFFFF);
			printf("[init]: Created consumer [%d]\n", task_creator_ctr_con);
			os_mut_release(g_mut_uart);
		#endif
	}
	
	// os_tsk_create(updater_task, 10);
	
	os_tsk_delete_self();
}
	
	
/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) {                     /* program execution starts here       */

 	SystemInit();         /* initialize the LPC17xx MCU */
  uart0_init();         /* initilize the first UART */
  
	
	//#ifdef DEBUGGING
		//printf("Calling os_sys_init()...\n");
	//#endif
	
	/*
	_init_box (mpool, sizeof(mpool),    // initialize the 'mpool' memory for   
              sizeof(T_NUM));        // the membox dynamic allocation       
	
	*/
		
	buffer = malloc(N*sizeof(int));
	if(buffer == NULL)
		printf("Not enough memory!\n");
	else
		printf("Global Circular buffer allocated!\n");


	
	os_sys_init(init);	  /* initilize the OS and start the first task */
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/
