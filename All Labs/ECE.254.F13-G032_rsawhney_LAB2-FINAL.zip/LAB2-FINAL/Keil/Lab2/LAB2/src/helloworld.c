/*----------------------------------------------------------------------------
 *      RL-ARM - RTX
 *----------------------------------------------------------------------------
 *      Name:    MAILBOX.C
 *      Purpose: RTX example program
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2011 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/
#include <LPC17xx.h>
#include "uart_polling.h"
#include <RTL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

OS_TID tsk1;                          /* assigned identification for task 1  */
OS_TID tsk2;                          /* assigned identification for task 2  */

OS_MUT g_mut_uart;
OS_TID g_tid = 255;

const U32 N = 20;
const U32 B = 2;

/*
U32 sendTaskCtr = 0;
U32 recvTaskCtr = 0;
*/

U32 msg_counter_rec = 0;
U32 msg_counter_send = 0;

//int N_arr[] = { 20, 40, 80, 160, 320 };
//int B_arr[] = { 1, 2, 4, 8, 10 };


typedef struct {                      /* Message object structure            */
  U32 number;                      		/* Random number */
} T_NUM;

os_mbx_declare (MsgBox,320);           /* Declare an RTX mailbox              */
_declare_box (mpool,sizeof(T_NUM),320);/* Dynamic memory pool                */



__task void send_task (void);
__task void rec_task (void);
//__task void updater_task (void);
__task void init(void);

U32 time_a, time_b, time_c;



/*----------------------------------------------------------------------------
 *  Task 1:  RTX Kernel starts this task with os_sys_init (send_task)
 *---------------------------------------------------------------------------*/
__task void send_task (void) {
  

	T_NUM *random_num_tx;
	
	//Get Time A
	time_a = os_time_get();
	
	// fork the child process
	tsk2 = os_tsk_create (rec_task, 0); /* start task 2                        */
  
	os_mbx_init (MsgBox, sizeof(MsgBox));/* initialize the mailbox             */
 
	os_mut_wait(g_mut_uart, 0xFFFF);
	printf("Mailbox Created\n");
	os_mut_release(g_mut_uart);
	
	//Get Time B
	time_b = os_time_get() ;

		
	while (msg_counter_send < N)
	{
		random_num_tx = _alloc_box(mpool);			/* Allocate a memory for the message   */
	
		if( random_num_tx == NULL )
		{
			os_mut_wait(g_mut_uart, 0xFFFF);
			printf("_alloc_box failed because of no mem available!\n");
			os_mut_release(g_mut_uart);
			exit(1);
		}
		
		random_num_tx->number = (U32) rand() % 9;
		
		os_mbx_send (MsgBox, random_num_tx, 0xffff); /* Send the message to the mailbox     */
		
		os_mut_wait(g_mut_uart, 0xFFFF);
		printf("[send_task (%d) ]: Sent %u\n", msg_counter_send, random_num_tx->number);
		msg_counter_send++;
		os_mut_release(g_mut_uart);
		
		
		// os_dly_wait (100);
	}
	
	//msg_counter_send = 0;
		
	os_tsk_delete_self ();              /* We are done here, delete this task  */
}

/*----------------------------------------------------------------------------
 *  Task 2: RTX Kernel starts this task with os_tsk_create (rec_task, 0)
 *---------------------------------------------------------------------------*/
__task void rec_task (void) {

	T_NUM *random_num_rx;



	while( msg_counter_rec < N )
	{
		os_mbx_wait (MsgBox, (void **)&random_num_rx, 0xffff); /* wait for the message    */
		
		os_mut_wait(g_mut_uart, 0xFFFF);
		printf("[rec_task (%d)]: Received %u\n", msg_counter_rec, random_num_rx->number);
		msg_counter_rec += 1;
		os_mut_release(g_mut_uart);
		
		if( _free_box (mpool, random_num_rx) )           /* free memory allocated for message  */
		{
			os_mut_wait(g_mut_uart, 0xFFFF);
			printf("_free_box failed because memory couldn't be freed\n");
			os_mut_release(g_mut_uart);
			exit(1);
			
		}
	}


	//Get Time C 
	time_c = os_time_get();
	
	os_mut_wait(g_mut_uart, 0xFFFF);
	printf("Time to initialize system: %0.6f\n", (float)(((float)time_b - time_a)/1000000) );
	printf("Time to transmit data: %0.6f\n", (float)(((float)time_c - time_b)/1000000) );
	os_mut_release(g_mut_uart);

	// os_dly_wait(10);
	os_tsk_delete_self ();              /* We are done here, delete this task  */
}


/*
__task void updater_task (void) {
	
	int i = 0;
	int j = 0;
	
	for(; i < 5; i++)
	{
		for(; j < 5; j++)
		{
			os_mut_wait(g_mut_uart, 0xFFFF);
			N = N_arr[i];
			B = B_arr[j];
			printf("N = %d\t B = %d\n", N, B);
			os_mut_release(g_mut_uart);
			os_dly_wait(100000);
			
		}
	}
}
*/
		
__task void init(void)
{
	os_mut_init(&g_mut_uart);
	
	os_tsk_create(send_task, 0);
	
	// os_tsk_create(updater_task, 10);
	
	os_tsk_delete_self();
}
	
	
/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) {                     /* program execution starts here       */

 	SystemInit();         /* initialize the LPC17xx MCU */
  uart0_init();         /* initilize the first UART */
  
	

  printf("Calling os_sys_init()...\n");

	
	_init_box (mpool, sizeof(mpool),    /* initialize the 'mpool' memory for   */
              sizeof(T_NUM));        /* the membox dynamic allocation       */
	os_sys_init(init);	  /* initilize the OS and start the first task */
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/
