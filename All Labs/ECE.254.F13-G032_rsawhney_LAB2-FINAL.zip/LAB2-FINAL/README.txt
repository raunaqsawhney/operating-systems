README

Linux:
get the lab2_linux.c file and compile it using GCC. gcc lab2_linux.c -o produce -lrt

This will create an executable called produce. This is run through ./produce N B where N and B are passed in by the user. 


Keil:
To run project in Keil, open the project (HelloWorld) in Keil, Batch Build, then Load and finally run the RAM target on the board. Make sure Putty is open and connected serially to the board, with appropriate baud rate. 